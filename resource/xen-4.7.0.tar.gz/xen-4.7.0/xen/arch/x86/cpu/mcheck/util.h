#ifndef _MCHECK_UTIL_H
#define _MCHECK_UTIL_H

void mce_panic_check(void);

#endif
