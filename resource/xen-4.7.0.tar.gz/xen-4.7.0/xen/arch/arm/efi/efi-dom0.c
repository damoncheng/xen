/*
 *  efi-dom0.c - Domain0 EFI Boot Support
 *
 *  Copyright (C) 2016 Shannon Zhao <shannon.zhao@linaro.org>
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; If not, see <http://www.gnu.org/licenses/>.
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

#include "efi.h"
#include "efi-dom0.h"
#include <xen/sched.h>
#include <xen/pfn.h>
#include <xen/libfdt/libfdt.h>
#include <asm/setup.h>
#include <asm/acpi.h>
#include "../../../common/decompress.h"
#define XZ_EXTERN STATIC
#include "../../../common/xz/crc32.c"

struct meminfo __initdata acpi_mem;
/* Constant to indicate "Xen" in unicode u16 format */
static const CHAR16 xen_efi_fw_vendor[] = {0x0058, 0x0065, 0x006E, 0x0000};

size_t __init estimate_efi_size(int mem_nr_banks)
{
    size_t size;
    size_t est_size = sizeof(EFI_SYSTEM_TABLE);
    size_t ect_size = sizeof(EFI_CONFIGURATION_TABLE);
    size_t emd_size = sizeof(EFI_MEMORY_DESCRIPTOR);
    size_t fw_vendor_size = sizeof(xen_efi_fw_vendor);
    int acpi_mem_nr_banks = 0;

    if ( !acpi_disabled )
        acpi_mem_nr_banks = acpi_mem.nr_banks;

    size = ROUNDUP(est_size + ect_size + fw_vendor_size, 8);
    /* plus 1 for new created tables */
    size += ROUNDUP(emd_size * (mem_nr_banks + acpi_mem_nr_banks + 1), 8);

    return size;
}

void __init acpi_create_efi_system_table(struct domain *d,
                                         struct membank tbl_add[])
{
    u64 table_addr, table_size, offset = 0;
    u8 *base_ptr;
    EFI_CONFIGURATION_TABLE *efi_conf_tbl;
    EFI_SYSTEM_TABLE *efi_sys_tbl;

    table_addr = d->arch.efi_acpi_gpa
                 + acpi_get_table_offset(tbl_add, TBL_EFIT);
    table_size = sizeof(EFI_SYSTEM_TABLE) + sizeof(EFI_CONFIGURATION_TABLE)
                 + sizeof(xen_efi_fw_vendor);
    base_ptr = d->arch.efi_acpi_table
               + acpi_get_table_offset(tbl_add, TBL_EFIT);
    efi_sys_tbl = (EFI_SYSTEM_TABLE *)base_ptr;

    efi_sys_tbl->Hdr.Signature = EFI_SYSTEM_TABLE_SIGNATURE;
    /* Specify the revision as 2.5 */
    efi_sys_tbl->Hdr.Revision = (2 << 16 | 50);
    efi_sys_tbl->Hdr.HeaderSize = table_size;

    efi_sys_tbl->FirmwareRevision = 1;
    efi_sys_tbl->NumberOfTableEntries = 1;
    offset += sizeof(EFI_SYSTEM_TABLE);
    memcpy(base_ptr + offset, xen_efi_fw_vendor, sizeof(xen_efi_fw_vendor));
    efi_sys_tbl->FirmwareVendor = (CHAR16 *)(table_addr + offset);

    offset += sizeof(xen_efi_fw_vendor);
    efi_conf_tbl = (EFI_CONFIGURATION_TABLE *)(base_ptr + offset);
    efi_conf_tbl->VendorGuid = (EFI_GUID)ACPI_20_TABLE_GUID;
    efi_conf_tbl->VendorTable = (VOID *)tbl_add[TBL_RSDP].start;
    efi_sys_tbl->ConfigurationTable = (EFI_CONFIGURATION_TABLE *)(table_addr
                                                                  + offset);
    xz_crc32_init();
    efi_sys_tbl->Hdr.CRC32 = xz_crc32((uint8_t *)efi_sys_tbl,
                                      efi_sys_tbl->Hdr.HeaderSize, 0);

    tbl_add[TBL_EFIT].start = table_addr;
    tbl_add[TBL_EFIT].size = table_size;
}

void __init acpi_create_efi_mmap_table(struct domain *d,
                                       const struct meminfo *mem,
                                       struct membank tbl_add[])
{
    EFI_MEMORY_DESCRIPTOR *memory_map;
    unsigned int i, offset;
    u8 *base_ptr;

    base_ptr = d->arch.efi_acpi_table
               + acpi_get_table_offset(tbl_add, TBL_MMAP);
    memory_map = (EFI_MEMORY_DESCRIPTOR *)base_ptr;

    offset = 0;
    for( i = 0; i < mem->nr_banks; i++, offset++ )
    {
        memory_map[offset].Type = EfiConventionalMemory;
        memory_map[offset].PhysicalStart = mem->bank[i].start;
        BUG_ON(mem->bank[i].size & EFI_PAGE_MASK);
        memory_map[offset].NumberOfPages = EFI_SIZE_TO_PAGES(mem->bank[i].size);
        memory_map[offset].Attribute = EFI_MEMORY_WB;
    }

    for( i = 0; i < acpi_mem.nr_banks; i++, offset++ )
    {
        memory_map[offset].Type = EfiACPIReclaimMemory;
        memory_map[offset].PhysicalStart = acpi_mem.bank[i].start;
        BUG_ON(acpi_mem.bank[i].size & EFI_PAGE_MASK);
        memory_map[offset].NumberOfPages = EFI_SIZE_TO_PAGES(acpi_mem.bank[i].size);
        memory_map[offset].Attribute = EFI_MEMORY_WB;
    }

    memory_map[offset].Type = EfiACPIReclaimMemory;
    memory_map[offset].PhysicalStart = d->arch.efi_acpi_gpa;
    BUG_ON(d->arch.efi_acpi_len & EFI_PAGE_MASK);
    memory_map[offset].NumberOfPages = EFI_SIZE_TO_PAGES(d->arch.efi_acpi_len);
    memory_map[offset].Attribute = EFI_MEMORY_WB;

    tbl_add[TBL_MMAP].start = d->arch.efi_acpi_gpa
                              + acpi_get_table_offset(tbl_add, TBL_MMAP);
    tbl_add[TBL_MMAP].size = sizeof(EFI_MEMORY_DESCRIPTOR)
                             * (mem->nr_banks + acpi_mem.nr_banks + 1);
}

/* Create /hypervisor/uefi node for efi properties. */
int __init acpi_make_efi_nodes(void *fdt, struct membank tbl_add[])
{
    int res;

    res = fdt_begin_node(fdt, "uefi");
    if ( res )
        return res;

    res = fdt_property_u64(fdt, "xen,uefi-system-table",
                           tbl_add[TBL_EFIT].start);
    if ( res )
        return res;

    res = fdt_property_u64(fdt, "xen,uefi-mmap-start",
                           tbl_add[TBL_MMAP].start);
    if ( res )
        return res;

    res = fdt_property_u32(fdt, "xen,uefi-mmap-size",
                           tbl_add[TBL_MMAP].size);
    if ( res )
        return res;

    res = fdt_property_u32(fdt, "xen,uefi-mmap-desc-size",
                           sizeof(EFI_MEMORY_DESCRIPTOR));
    if ( res )
        return res;

    res = fdt_property_u32(fdt, "xen,uefi-mmap-desc-ver", 1);
    if ( res )
        return res;

    res = fdt_end_node(fdt);

    return res;
}

/*
 * Local variables:
 * mode: C
 * c-file-style: "BSD"
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
